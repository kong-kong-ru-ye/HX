//TechTreeFunctions
const lib = require("前置/全部引用及前置");

const nodeRoot = TechTree.nodeRoot;
const node = TechTree.node;

nodeRoot("我的幻想", lib.lib.方块 ("幻想核心"), false, () => {
    node(lib.lib.方块 ("环境改造核心"), () => {
        node(lib.lib.物品 ("环境改造-矿"), () => {});
        node(
        lib.lib.方块 ("hjgz-dxtq-kw"), () => {
            node(
            lib.lib.方块 ("hjgz-dxtc-kw"), () => {})
        });
    });
    node(lib.lib.方块 ("原油精炼核心"), () => {});
});