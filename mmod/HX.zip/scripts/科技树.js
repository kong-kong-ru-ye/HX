//TechTreeFunctions
const lib = require("前置/全部引用及前置");

const nodeRoot = TechTree.nodeRoot;
const node = TechTree.node;

nodeRoot("我的幻想", lib.lib.方块 ("幻想核心"), false, () => {
    node(lib.lib.方块 ("环境改造核心"), () => {
        node(lib.lib.物品 ("铜"), () => {
            node(lib.lib.物品 ("铅"), () => {
                node(lib.lib.物品 ("煤"), () => {})
                node(lib.lib.物品 ("钛"), () => {
                    node(lib.lib.物品 ("钍"), () => {})
                })
            })
            node(lib.lib.物品 ("铍"), () => {
                node(lib.lib.物品 ("钨"), () => {})
            })
        });
        node(
        lib.lib.方块 ("hjgz-dxtq-kw"), () => {
            node(
            lib.lib.方块 ("hjgz-dxtc-kw"), () => {})
        });
    });
    node(lib.lib.方块 ("原油精炼核心"), () => {
        node(Liquids.oil, () => {
            node(lib.lib.流体 ("重油"), () => {
                node(Items.plastanium, () => {})
            })
            node(lib.lib.流体 ("轻油"), () => {
                node(Items.plastanium, () => {})
            })
            node(lib.lib.流体 ("可燃气"), () => {})
            node(lib.lib.流体 ("沥青"), () => {})
        })
        node(lib.lib.方块 ("yyjl-yy"), () => {})
    });
});
/*
item.copper.name = 铜
item.lead.name = 铅
item.coal.name = 煤炭
item.graphite.name = 石墨
item.titanium.name = 钛
item.thorium.name = 钍
item.silicon.name = 硅
item.plastanium.name = 塑钢
item.phase-fabric.name = 相位织物
item.surge-alloy.name = 巨浪合金
item.spore-pod.name = 孢子荚
item.sand.name = 沙
item.blast-compound.name = 爆炸混合物
item.pyratite.name = 硫化物
item.metaglass.name = 钢化玻璃
item.scrap.name = 废料

item.fissile-matter.name = 裂变物质
item.beryllium.name = 铍
item.tungsten.name = 钨
item.oxide.name = 氧化物
item.carbide.name = 碳化物
item.dormant-cyst.name = 休眠囊肿

liquid.water.name = 水
liquid.slag.name = 矿渣液
liquid.oil.name = 石油
liquid.cryofluid.name = 冷冻液
liquid.neoplasm.name = 囊肿血浆
liquid.arkycite.name = 芳油
liquid.gallium.name = 镓液
liquid.ozone.name = 臭氧
liquid.hydrogen.name = 氢气
liquid.nitrogen.name = 氮气
liquid.cyanogen.name = 氰气
*/