
//try {
//require("原版绘制")
require("通用方块/隐藏的科技方块");

require("环境改造/物质");
//require("环境改造/阿尔山");
require("环境改造/河道");
require("环境改造/提取矿物");
require("环境改造/填充矿物");


require("原油精炼/物质");
require("原油精炼/原油精炼厂");

require("newPlanet");
require("科技树");

// } catch (e) {
//  print("发生了错误: ⇨⇨⇨⇨⇨" + e);
// }