const lib = require("前置/全部引用及前置");
exports.提取矿物方法 = (name, hjk, p, 血量, 容量, as,BuildVisibility, Category) => {
    const a = extend(Block, name, { //环境改造-地形提取-矿物
        setBars() {
            this.super$setBars();
            this.addBar("提取",
            func(e => new Bar(
            prov(() => e.d1() + e.b1()),
            prov(() => Color.valueOf("#C2FFDD"), 1),
            floatp(() => 1))));
        }
    });
    a.buildType = prov(() => {
        return extend(Building, {
            init(tile, team, shouldAdd, rotation) {
                if (!this.initialized) this.create(tile.block(), team)
                else if (this.block.hasPower) {
                    this.power.init = false;
                    new PowerGraph()
                        .add(this);
                };
                this.proximity.clear();
                this.rotation = rotation;
                this.tile = tile;
                this.set(tile.drawx(), tile.drawy());
                if (shouldAdd) this.add();
                this.created();

                this.a0(null);
                this.b0(null);
                return this;
            },
            updateTile() {
                this.dump()
                if (this.timer.get(hjk)) {
                    for (let i in p) {
                        let a = this.tile.nearby(p[i].x, p[i].y)
                            .overlay(); //检测覆盖层
                        a == Blocks.air ? this.b0(lib.lib.翻译A("block", "hjgz-dxtq-kw-a")) : this.b0(a);
                        switch (a) {
                            case Blocks.oreCopper:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("铜"), 1);
                                break;
                            case Blocks.oreLead:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("铅"), 1);
                                break;
                            case Blocks.oreScrap:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("废料"), 1);
                                break;
                            case Blocks.oreCoal:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("煤"), 1);
                                break;
                            case Blocks.oreTitanium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钛"), 1);
                                break;
                            case Blocks.oreThorium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钍"), 1);
                                break;
                            case Blocks.oreBeryllium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("铍"), 1);
                                break;
                            case Blocks.oreTungsten:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钨"), 1);
                                break;
                            case Blocks.oreCrystalThorium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钍"), 1);
                                break;
                            case Blocks.wallOreThorium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钍"), 1);
                                break;
                            case Blocks.wallOreBeryllium:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("铍"), 1);
                                break;
                            case Blocks.wallOreTungsten:
                                this.c1(i);
                                this.items.add(lib.lib.物品 ("钨"), 1);
                                break;
                        }
                    }
                }
            },
            a0(a) {
                this.a = a;
            },
            a1() {
                return this.a;
            },
            b0(a) {
                this.b = a;
            },
            b1() {
                return this.b;
            },
            c1(i) {
                let b = this.tile.nearby(p[i].x, p[i].y)
                    .floor(); //检测地板
                this.tile.nearby(p[i].x, p[i].y)
                    .setFloorNet(b, Blocks.air);
                return;
            },
            d1() {
                return lib.lib.翻译A("block", "hjgz-dxtq-kw-c");
            },
            draw() { //绘制
                this.super$draw();
                let a = Vars.world.tile(this.tileX(), this.tileY())
                    .overlay(); //检测覆盖层
                a == Blocks.air ? Draw.color(lib.颜色.红色) : Draw.color(lib.颜色.白色);
                Draw.alpha(0.5); //透明度
                //Draw.blend(Blending.additive); //混合
                Draw.z(86); //涂层层数?
                Draw.rect(lib.lib.材质 ("hjgz-kw"), this.x, this.y, 32, 32, Time.time);
                Draw.alpha(1); //透明度
                Drawf.dashSquare(this.team.color, this.x, this.y, 8*as); //短划线🔲(颜色,{坐标},宽,高)
            }
        });
    });
    a.update = true;
    a.health = 血量; //血量
    a.size = 1; //大小
    a.hasItems = true;
    a.flameColor = Color.valueOf("ffc099");
    a.itemCapacity = 容量; //物品容量
    a.buildVisibility = BuildVisibility;
    a.category = Category;

};