
const 手摇发电机 = extend(SolarGenerator, '手摇发电机', {
});
手摇发电机.localizedName = '手摇发电机';
手摇发电机.buildVisibility = BuildVisibility.shown;
手摇发电机.category = Category.power;
手摇发电机.update = 手摇发电机.configurable = 手摇发电机.hasPower = true;
手摇发电机.powerProduction = 150;//电量上限，1:60
手摇发电机.buildType = prov(() => {
    var productionEfficiency = 3600;
    const max = 150;
    return new JavaAdapter(SolarGenerator.SolarGeneratorBuild, {
	getPowerProduction(){
		return this.productionEfficiency;
	},
	write(write){
		this.super$write(write);
		write.f(this.productionEfficiency);
	},
	read(read, revision){
		this.super$read(read, revision);
		this.productionEfficiency = read.f();
	}
},手摇发电机);
});

