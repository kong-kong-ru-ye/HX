const lib = require("前置/全部引用及前置");
const a = require("环境改造/提取矿物方法");


//exports.提取矿物方法 = (name, timer, p, 血量, 容量, as,BuildVisibility, Category)
a.提取矿物方法("hjgz-dxtq-kw", 300, lib.检测.零数组, 60, 10, 1, BuildVisibility.shown, Category.crafting);
a.提取矿物方法("hjgz-dxtq-kw-2", 300, lib.检测.三三数组, 60, 10, 3, BuildVisibility.shown, Category.crafting);
