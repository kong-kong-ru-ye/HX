const dl1 = extend(Floor, "hjgz-dsh-dl1", {});


const a = extend(Wall, "hjgz-dsh-dl", {}); //环境改造-都市化-道路
a.update = true;
a.buildType = prov(() => {
    return extend(Building, {
        updateTile() {
            let b = Vars.world.tile(this.tileX(), this.tileY())
                .overlay();
            Vars.world.tile(this.tileX(), this.tileY())
                .setFloorNet(dl1, b);
                Vars.world.tile(this.tileX(), this.tileY()).setAir();
        }
    })
});
a.buildVisibility = BuildVisibility.shown;
a.category = Category.crafting;
const b = extend(Wall, "hjgz-dsh-dl-2", {}); //环境改造-都市化-道路2
b.update = true;
b.buildType = prov(() => {
    return extend(Building, {
        updateTile() {
            Vars.world.tile(this.tileX(), this.tileY())
                .setFloorNet(dl1, Blocks.air);
                Vars.world.tile(this.tileX(), this.tileY()).setAir();
        }
    })
});
b.buildVisibility = BuildVisibility.shown;
b.category = Category.crafting;