exports.circlePercent = (x, y, 半径, 百分比, 起始角度) => {
    //来自(EU)更多实用设
    //if(p < 0.001) return;
    var p = Mathf.clamp(百分比);
    var sides = Lines.circleVertices(半径);
    var space = 360 / sides;
    var len = 2 * 半径 * Mathf.sinDeg(space / 2);
    var hstep = Lines.getStroke() / 2 / Mathf.cosDeg(space / 2);
    var r1 = 半径 - hstep;
    var r2 = 半径 + hstep;
    var i;
    for (i = 0; i < sides * p - 1; ++i) {
        var a = space * i + 起始角度;
        var cos = Mathf.cosDeg(a);
        var sin = Mathf.sinDeg(a);
        var cos2 = Mathf.cosDeg(a + space);
        var sin2 = Mathf.sinDeg(a + space);
      return  Fill.quad(x + r1 * cos, y + r1 * sin, x + r1 * cos2, y + r1 * sin2, x + r2 * cos2, y + r2 * sin2, x + r2 * cos, y + r2 * sin);
    }
    var a = space * i + 起始角度;
    var cos = Mathf.cosDeg(a);
    var sin = Mathf.sinDeg(a);
    var cos2 = Mathf.cosDeg(a + space);
    var sin2 = Mathf.sinDeg(a + space);
    var f = sides * p - i;
    var vec = new Vec2();
    vec.trns(a, 0, len * (f - 1));
   return Fill.quad(x + r1 * cos, y + r1 * sin, x + r1 * cos2 + vec.x, y + r1 * sin2 + vec.y, x + r2 * cos2 + vec.x, y + r2 * sin2 + vec.y, x + r2 * cos, y + r2 * sin);
};
let b = new DrawRegion("-bottom");
let c = new DrawLiquidTile(Liquids.oil, 2);
let d = new DrawBubbles(Color.valueOf("85878D"));
d.sides = 10;
d.recurrence = 3;
d.spread = 6;
d.radius = 1.5;
d.amount = 20;
let e = new DrawRegion();
let f = new DrawLiquidOutputs();
let g = new DrawGlowRegion()
g.alpha = 0.7;
g.color = Color.valueOf("797A7E");
g.glowIntensity = 0.3;
g.glowScale = 6;
exports.电解机特效 = new DrawMulti(b, c, d, e, f, g);