
//类型
exports.测试 = new StatCat("测试信息类型");
exports.kfqso = new StatCat("aa");

//自定义能能量
exports.自定义能量 = new StatCat("自定义能量");

exports.特殊内容 = new StatCat("特殊内容");

