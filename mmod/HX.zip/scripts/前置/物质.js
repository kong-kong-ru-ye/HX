const lib = require("前置/全部引用及前置");
exports.物质1 = (名字, 类型, 颜色, 气体) => {
    this.颜色 = 颜色 == null ? lib.颜色.白色 : 颜色;
    this.名字 = 名字;
    this.类型 = [Item, Liquid];
    this.气体 = 气体 == null ? false : true;
    const a = extend(this.类型 [类型], this.名字, {
        setStats() {
            this.super$setStats();
            this.stats.remove(Stat.charge);
            this.stats.remove(Stat.radioactivity);
            this.stats.remove(Stat.flammability);
            this.stats.remove(Stat.explosiveness);
        }
    });
    a.hidden = true; //隐藏的
    if (类型 == 1) {
        a.gas = this.开关 [this.气体]; //是否是气体
        a.barColor = this.颜色
    }
    a.color = this.颜色;
    return a
};



