const lib = require("前置/全部引用及前置");
exports.物质1 = (名字, 类型, 颜色, 气体) => {
    this.颜色 = 颜色 == null ? lib.颜色.白色 : 颜色;
    this.名字 = 名字;
    this.类型 = [Item, Liquid];
    this.气体 = 气体 == null ? false : true;
    const a = extend(this.类型 [类型], this.名字, {
        setStats() {
            this.super$setStats();
            this.stats.remove(Stat.charge);
            this.stats.remove(Stat.radioactivity);
            this.stats.remove(Stat.flammability);
            this.stats.remove(Stat.explosiveness);
        }
    });
    a.hidden = true; //隐藏的
    if (类型 == 1) {
        a.gas = this.气体; //是否是气体
        a.barColor = this.颜色
    }
    a.color = this.颜色;
    return a
};

exports.物质2 = (名字, 颜色, 材质数量, 中间帧, 材质帧, true建筑false燃料, 是否隐藏, 生命比例, 放射性, 燃烧性, 放电性, 爆炸性, 建筑惩罚, 挖掘等级, 默认解锁) => {
    const item = extend(Item, 名字, {});

    item.frames = 材质数量; //材质数量？
    item.transitionFrames = 中间帧; //图片的中间帧？
    item.frameTime = 材质帧; //每张图片的帧？

    //item.lowPriority = true采集最低优先级;//true 采集最低优先级
    item.buildable = true建筑false燃料; //true建筑false燃料
    item.hidden = 是否隐藏; //是否隐藏

    item.healthScaling = 生命比例; //生命比例？与cost擦不多()？

    item.color = 颜色;
    item.radioactivity = 放射性; //放射性
    item.flammability = 燃烧性; //燃烧性
    item.charge = 放电性; //放电性
    item.explosiveness = 爆炸性; //爆炸性;
    item.cost = 建筑惩罚; //建筑时间
    item.hardness = 挖掘等级; //挖掘
    item.alwaysUnlocked = 默认解锁;
    item.inlineDescription = true; //解锁前描述
    return item;
};
exports.物质3 = (名字, 材质数量, 中间帧, 材质帧) => {
    const item = extend(Item, 名字, {
        unlockedNowHost() {
            return false
        }, //↓（同吧？）
        unlockedNow() {
            return false
        }, //返回此内容是否已解锁，或者玩家是否在自定义（非战役）游戏中。
    });

    item.frames = 材质数量; //材质数量？
    item.transitionFrames = 中间帧; //图片的中间帧？
    item.frameTime = 材质帧; //每张图片的帧？
    item.alwaysUnlocked = true; //默认解锁
    item.inlineDescription = true; //解锁前描述
    return item;
};
exports.物质4 = (名字, 颜色, 材质数量, 中间帧, 材质帧, true建筑false燃料, 是否隐藏, 生命比例, 放射性, 燃烧性, 放电性, 爆炸性, 建筑惩罚, 挖掘等级, 默认解锁) => {
    const item = extend(Item, 名字, {
        unlockedNowHost() {
            return false
        }, //↓（同吧？）
        unlockedNow() {
            return false
        }, //返回此内容是否已解锁，或者玩家是否在自定义（非战役）游戏中。

    });
    item.frames = 材质数量; //材质数量？
    item.transitionFrames = 中间帧; //图片的中间帧？
    item.frameTime = 材质帧; //每张图片的帧？

    //item.lowPriority = true采集最低优先级;//true 采集最低优先级
    item.buildable = true建筑false燃料; //true建筑false燃料
    item.hidden = 是否隐藏; //是否隐藏

    item.healthScaling = 生命比例; //生命比例？与cost擦不多()？

    item.color = 颜色;
    item.radioactivity = 放射性; //放射性
    item.flammability = 燃烧性; //燃烧性
    item.charge = 放电性; //放电性
    item.explosiveness = 爆炸性; //爆炸性;
    item.cost = 建筑惩罚; //建筑时间
    item.hardness = 挖掘等级; //挖掘
    item.alwaysUnlocked = 默认解锁;
    item.inlineDescription = true; //解锁前描述
    return item;
};

exports.物质5 = (名字, 是否发光, 颜色, 是否气体, 是否冷却液, 沸点, 是否隐藏, 燃烧性, 爆炸性, 温度, 黏度, 热容量, 默认解锁) => {
    const liquid = extend(Liquid, 名字, {});

    liquid.gas = 是否气体; //是否是气体
    liquid.coolant = 是否冷却液; //冷却液？
    liquid.particleEffect = Fx.vapor; //在水坑的效果粒子
    liquid.particleSpacing = 120; //粒子特效速率
    liquid.boilPoint = 沸点; //沸点
    liquid.capPuddles = true; //水坑气体特效的范围
    liquid.vaporEffect = Fx.vapor; //气体特效
    liquid.hidden = 是否隐藏; //隐藏的

    liquid.emitLight = 是否发光
    liquid.color = 颜色;
    liquid.lightColor = 颜色;
    liquid.barColor = 颜色;
    liquid.effect = StatusEffects.none; //特效
    liquid.flammability = 燃烧性; //燃烧性
    liquid.explosiveness = 爆炸性; //爆炸性
    liquid.temperature = 温度; //温度
    liquid.viscosity = 黏度; //粘度
    liquid.heatCapacity = 热容量; //热容量
    liquid.alwaysUnlocked = 默认解锁; //是否默认开启
    liquid.inlineDescription = true; //解锁前描述
    return liquid;
};