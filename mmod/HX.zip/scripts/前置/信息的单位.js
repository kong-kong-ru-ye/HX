
//单位
exports.测试 = new StatUnit("测试");
exports.级 = new StatUnit("aa");//级

