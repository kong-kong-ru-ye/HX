const lib = require("前置/全部引用及前置");


//信息
exports.测试 = new Stat("测试信息",lib.类型A.测试);
exports.采集等级 = new Stat("aa");//所需采集等级
//var healthh = new Stat("healuhbduth", ral);
//自定义能量
exports.传输 = new Stat("自定义能量传输", lib.类型A.自定义能量),
exports.存储 = new Stat("自定义能量存储", lib.类型A.自定义能量),
exports.使用 = new Stat("自定义能量使用", lib.类型A.自定义能量),
exports.输出 = new Stat("自定义能量输出", lib.类型A.自定义能量);

exports.环境改造矿 = new Stat("环境改造-矿", lib.类型A.特殊内容);


