

function 颜色(name){
return Color.valueOf(name);
};

exports.白色 = 颜色("FFFFFF");
exports.黄色 = 颜色("FFFF00");
exports.粉色 = 颜色("FF00FF");
exports.青蓝 = 颜色("00FFFF");
exports.红色 = 颜色("FF0000");
exports.绿色 = 颜色("00FF00");
exports.深蓝 = 颜色("0000FF");
exports.黑色 = 颜色("000000");
exports.可燃气 = 颜色("FFD07A");
exports.重油 = 颜色("FFA77A");
exports.轻油 = 颜色("E7B350");
exports.颜色 = 颜色;