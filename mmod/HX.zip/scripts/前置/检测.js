exports.十字数组 = [
{x: 1,y: 0}, 
{x: 0,y: -1}, 
{x: -1,y: 0}, 
{x: 0,y: 1}];
exports.零数组 = [{x:0,y:0}];
exports.三三数组 = [
{x: 1,y: 0}, 
{x: 1,y: -1}, 
{x: 0,y: -1}, 
{x: -1,y: -1}, 
{x: -1,y: 0}, 
{x: -1,y: 1}, 
{x: 0,y: 1},
{x: 1,y: 1},
{x:0,y:0}
];
exports.空九数组 = [
{x: 1,y: 0}, 
{x: 1,y: -1}, 
{x: 0,y: -1}, 
{x: 1,y: -1}, 
{x: -1,y: 0}, 
{x: -1,y: 1}, 
{x: 0,y: 1},
{x: 1,y: 1}
];
exports.液体地板1 = [ //水
Blocks.deepwater,
Blocks.water,
Blocks.sandWater,
Blocks.darksandWater]; //深水 水 浅滩 黑沙浅滩
exports.液体地板2 = [ //污水
Blocks.taintedWater,
Blocks.deepTaintedWater,
Blocks.darksandTaintedWater] ///污水 深污水 黑沙污水
exports.液体地板3 = [ //特殊
Blocks.tar,
Blocks.cryofluid,
Blocks.slag]; //石油 冷冻液 矿渣
exports.液体地板4 = [ //水
Blocks.water,
Blocks.sandWater,
Blocks.darksandWater]; //水 浅滩 黑沙浅滩
exports.液体地板5 = [ //污水
Blocks.taintedWater,
Blocks.darksandTaintedWater] ///污水 黑沙污水