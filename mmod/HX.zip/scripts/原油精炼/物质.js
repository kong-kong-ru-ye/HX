const lib = require("前置/全部引用及前置");
lib.物质.物质1 ("重油", 1, lib.颜色.重油, null);
lib.物质.物质1 ("轻油", 1, lib.颜色.轻油, null);
lib.物质.物质1 ("可燃气", 1, lib.颜色.可燃气, 0);
lib.物质.物质1 ("沥青", 1, lib.颜色.黑色, null);






                /*
Items.copper = 铜
Items.lead = 铅
Items.coal = 煤炭
Items.graphite = 石墨
Items.titanium = 钛
Items.thorium = 钍
Items.silicon = 硅
Items.plastanium = 塑钢
Items.phase-fabric = 相位织物
Items.surge-alloy = 巨浪合金
Items.spore-pod = 孢子荚
Items.sand = 沙
Items.blast-compound = 爆炸混合物
Items.pyratite = 硫化物
Items.metaglass = 钢化玻璃
Items.scrap = 废料

Items.fissile-matter = 裂变物质
Items.beryllium = 铍
Items.tungsten = 钨
Items.oxide = 氧化物
Items.carbide = 碳化物
Items.dormant-cyst = 休眠囊肿

Liquids.water = 水
Liquids.slag = 矿渣液
Liquids.oil = 石油
Liquids.cryofluid = 冷冻液
Liquids.neoplasm = 囊肿血浆
Liquids.arkycite = 芳油
Liquids.gallium = 镓液
Liquids.ozone = 臭氧
Liquids.hydrogen = 氢气
Liquids.nitrogen = 氮气
Liquids.cyanogen = 氰气*/