const lib = require("前置/全部引用及前置");

lib.物质.物质1 ("铜", 0, null, null);
lib.物质.物质1 ("铅", 0, null, null);
lib.物质.物质1 ("煤", 0, null, null);
lib.物质.物质1 ("钛", 0, null, null);
lib.物质.物质1 ("钍", 0, null, null);
lib.物质.物质1 ("废料", 0, null, null);
lib.物质.物质1 ("铍", 0, null, null);
lib.物质.物质1 ("钨", 0, null, null);


const a = extend(Item, "环境改造-矿", {
    unlockedNowHost() {
        return false;
    }, //↓（同吧？）
    unlockedNow() {
        return false;
    }, //返回此内容是否已解锁，或者玩家是否在自定义（非战役）游戏中。
    setStats() {
        this.super$setStats();
        this.stats.remove(Stat.charge);
        this.stats.remove(Stat.radioactivity);
        this.stats.remove(Stat.flammability);
        this.stats.remove(Stat.explosiveness);
        this.stats.add(lib.信息.环境改造矿, new JavaAdapter(StatValue, {
            display(table) {
                table.row();
                table.add(lib.lib.翻译A("item", "内容001"));
                table.row();
                table.table(cons(row => {
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("铜")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("铜"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("铅")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("铅"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("煤")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("煤"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("钛")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("钛"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("钍")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("钍"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("废料")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("废料"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("铍")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("铍"))})).size(64);
                        row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质("钨")), Styles.cleari, run(() => {Vars.ui.content.show(lib.lib.物品 ("钨"))})).size(64);
                        row.row();
                }))

            }
        }));
    }
});

                /*
Items.copper = 铜
Items.lead = 铅
Items.coal = 煤炭
Items.graphite = 石墨
Items.titanium = 钛
Items.thorium = 钍
Items.silicon = 硅
Items.plastanium = 塑钢
Items.phase-fabric = 相位织物
Items.surge-alloy = 巨浪合金
Items.spore-pod = 孢子荚
Items.sand = 沙
Items.blast-compound = 爆炸混合物
Items.pyratite = 硫化物
Items.metaglass = 钢化玻璃
Items.scrap = 废料

Items.fissile-matter = 裂变物质
Items.beryllium = 铍
Items.tungsten = 钨
Items.oxide = 氧化物
Items.carbide = 碳化物
Items.dormant-cyst = 休眠囊肿

Liquids.water = 水
Liquids.slag = 矿渣液
Liquids.oil = 石油
Liquids.cryofluid = 冷冻液
Liquids.neoplasm = 囊肿血浆
Liquids.arkycite = 芳油
Liquids.gallium = 镓液
Liquids.ozone = 臭氧
Liquids.hydrogen = 氢气
Liquids.nitrogen = 氮气
Liquids.cyanogen = 氰气*/