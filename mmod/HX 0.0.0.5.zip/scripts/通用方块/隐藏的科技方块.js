//科技树节点
function jd(name,size) {
    const a = extend(Wall, name, {
        isHidden() {
            return false
        },
        unlockedNowHost() {
            return false
        },
        unlockedNow() {
            return false
        }
    });
    a.size = size;
    a.buildVisibility = BuildVisibility.hidden;
    a.category = Category.defense;
    return a;
};

jd("幻想核心",9);
jd("环境改造核心",9);
jd("原油精炼核心",9);
jd("jjj",1);
jd("hhh",1);