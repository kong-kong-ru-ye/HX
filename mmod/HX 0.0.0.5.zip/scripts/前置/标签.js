

//标签
exports.测试 = new Attribute.add("aa");

exports.耕地 = new Attribute.add("ab");
exports.废虚A = new Attribute.add("ac");
exports.废虚B = new Attribute.add("ad");
exports.废虚C = new Attribute.add("ae");
exports.废虚D = new Attribute.add("af");
//能
exports.辐射能 = new Attribute.add("ca");
exports.灵能 = new Attribute.add("cb");
//喷泉
exports.水A = new Attribute.add("da");
exports.石油A = new Attribute.add("db");
exports.冷冻液A = new Attribute.add("dc");
exports.废液A = new Attribute.add("dd");
exports.氧气A = new Attribute.add("de");
exports.氢气A = new Attribute.add("df");
exports.氮气A = new Attribute.add("dg");
exports.氰气A = new Attribute.add("dh");
//富含
//exports.水B = new Attribute.add("ea");
//exports.石油B = new Attribute.add("eb");
exports.冷冻液B = new Attribute.add("ec");
exports.废液B = new Attribute.add("ed");
exports.氧气B = new Attribute.add("ee");
exports.氢气B = new Attribute.add("ef");
exports.氮气B = new Attribute.add("eg");
exports.氰气B = new Attribute.add("eh");

exports.冰 = new Attribute.add("fa");
exports.石头 = new Attribute.add("fb");
exports.可燃冰 = new Attribute.add("fc");

exports.环境冷却 = new Attribute.add("ga");
//exports.环境加热 = new Attribute.add("gb");
