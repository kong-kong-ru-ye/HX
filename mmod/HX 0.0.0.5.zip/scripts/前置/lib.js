exports.modName = "hx";

exports.setBuilding = function(blockType, buildingCreator) {
    blockType.buildType = prov(() => buildingCreator(blockType));
}

exports.setBuildingSimple = function(blockType, buildingType, overrides) {
    blockType.buildType = prov(() => new JavaAdapter(buildingType, overrides, blockType));
}

exports.setBuildingSimpleAA = function(blockType, buildingType, overridesGetter) {
    blockType.buildType = prov(() => new JavaAdapter(buildingType, overridesGetter(blockType), blockType));
}
exports.cons2 = (func) => new Cons2({
    get: (v1, v2) => func(v1, v2)
});
exports.方块 = (名字) => Vars.content.getByName(ContentType.block, exports.modName + "-" + 名字);
exports.单位 = (名字) => Vars.content.getByName(ContentType.unit, exports.modName + "-" + 名字);
exports.流体 = (名字) => Vars.content.getByName(ContentType.liquid, exports.modName + "-" + 名字);
exports.物品 = (名字) => Vars.content.getByName(ContentType.item, exports.modName + "-" + 名字);
exports.材质 = (名字) => Core.atlas.find(exports.modName + "-" + 名字, Core.atlas.find("clear"));
exports.翻译A = (类, 名字) => Core.bundle.format(类 + "." + exports.modName + "-" + 名字 + ".name");
exports.翻译B = (类, 名字, 数据) => {
    return Core.bundle.format(类 + "." + exports.modName + "-" + 名字 + ".name", 数据);
};
exports.方块2 = (MOD, 名字) => Vars.content.getByName(ContentType.block, MOD + "-" + 名字);
exports.单位2 = (MOD, 名字) => Vars.content.getByName(ContentType.unit, MOD + "-" + 名字);
exports.流体2 = (MOD, 名字) => Vars.content.getByName(ContentType.liquid, MOD + "-" + 名字);
exports.物品2 = (MOD, 名字) => Vars.content.getByName(ContentType.item, MOD + "-" + 名字);
exports.材质2 = (MOD, 名字) => Core.atlas.find(MOD + "-" + 名字, Core.atlas.find("clear"));
exports.翻译A2 = (类, MOD, 名字) => Core.bundle.format(类 + "." + MOD + "-" + 名字 + ".name");
exports.翻译B2 = (类, MOD, 名字, 数据) => {
    return Core.bundle.format(类 + "." + MOD + "-" + 名字 + ".name", 数据);
};
exports.翻译A3 = (类, 名字) => Core.bundle.format(类 + "." + 名字 + ".name");
exports.翻译B3 = (类, 名字, 数据) => {
    return Core.bundle.format(类 + "." + 名字 + ".name", 数据);
};
exports.材质3 = (名字) => Core.atlas.find(名字, Core.atlas.find("clear"));

exports.JAVA = (name) => {
    let loader = Vars.mods.mainLoader();
    let scripts = Vars.mods.scripts;
    let NativeJavaClass = Packages.rhino.NativeJavaClass;
    return NativeJavaClass(scripts.scope, loader.loadClass(name));
};
exports.科技树 = (content, research) => { //科技树
    if (!content) {
        throw new Error('content 科技是空!');
    }
    if (!research.parent) {
        throw new Error('research.parent 前置科技为空!');
    }
    var researchName = research.parent;
    var customRequirements = research.requirements;
    var objectives = research.objectives;
    var lastNode = TechTree.all.find(boolf(t => t.content == content));
    if (lastNode != null) {
        lastNode.remove();
    }
    var node = new TechTree.TechNode(null, content, customRequirements !== undefined ? customRequirements : content.researchRequirements());
    if (objectives) {
        node.objectives.addAll(objectives);
    }
    if (node.parent != null) {
        node.parent.children.remove(node);
    }
    // find parent node.
    var parent = TechTree.all.find(
    boolf(t => t.content.name.equals(researchName) || t.content.name.equals(modName + "-" + researchName)));
    if (parent == null) {
        throw new Error("内容" + researchName + "不在科技树，但" + content.name + "要求对其研究");
    }
    // add this node to the parent
    if (!parent.children.contains(node)) {
        parent.children.add(node);
    }
    // reparent the node
    node.parent = parent;
};