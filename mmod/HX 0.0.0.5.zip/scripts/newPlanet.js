
//planets
Planets.sun.accessible = Planets.tantros.accessible = Planets.gier.accessible = Planets.notva.accessible = Planets.verilus.accessible = true;
Planets.sun.alwaysUnlocked = Planets.tantros.alwaysUnlocked = Planets.gier.alwaysUnlocked = Planets.notva.alwaysUnlocked = Planets.verilus.alwaysUnlocked = true;

//planet
const np = new Planet("newPlanet", Planets.sun/*parent*/, 1.1/*radius*/, 2.2/*sectorSize*/);
np.meshLoader = prov(() => new MultiMesh(
	/*new HexMesh(np, 1),
	new HexMesh(np, 2),*/
	new SunMesh(np, 4, 6, 0.3, 1.8, 1.2, 1, 1.2, new Color(0.15, 0.3, 0.75, 0.5), new Color(0.15, 0.3, 0.75, 0.6), new Color(0.15, 0.3, 0.75, 0.7), Color(0.15, 0.3, 0.75, 0.8), new Color(0.15, 0.3, 0.75, 0.9), new Color(0.15, 0.3, 0.75, 1))
));
np.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(np/*planet*/, 0.8/*seed*/, 0.03/*speed*/, 0.15/*radius*/, 3/*divisions*/, new Color(0.75, 0.5, 1, 0.75)/*color*/, 2/*octaves*/, 0.45/*persistence*/, 1/*scl*/, 0.45/*thresh*/),
	new HexSkyMesh(np, 0.9, 0.06, 0.18, 6, new Color(0.25, 0.5, 0.75, 0.5), 1, 0.45, 1.2, 0.45),
	new HexSkyMesh(np, 1, 0.09, 0.21, 3, new Color(0.5, 0.25, 1, 0.5), 2, 0.6, 1.5, 0.6)
));
np.generator = extend(SerpuloPlanetGenerator, {
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgY2BjZmDJS8xNZWBNzi9KNWDgTkktTi7KLCjJzM9jYGBgy0lMSs0pZmCKjmVk4ExLLNaFKGNgYGRgYAJCBgAliA7E")
	},
	allowLanding(sector){
		return false/*默认为 sector.hasBase() || sector.near().contains(Sector::hasBase) 即攻打某一地区时, 周围地区默认解锁*/
	}
});
np.bloom/*光效*/ = np.visible = np.tidalLock = np.accessible = np.alwaysUnlocked = np.clearSectorOnLose/*战败重置*/ = true;
np.startSector = 0;
np.rotateTime = 90;
np.orbitTime = 180;
np.orbitRadius = 44;
np.atmosphereRadIn = 0.1;
np.atmosphereRadOut = 1;
np.localizedName = "newPlanet";
np.atmosphereColor = np.landCloudColor = np.lightColor = new Color(0.75, 0.5, 0.25, 0.8);
//np.hiddenItems.addAll(items.originalItems).removeAll(items.npOnlyItems);

//sector
// const none = new SectorPreset("none", np, 0);
// none.alwaysUnlocked = none.addStartingItems = false;
// none.difficulty = 2;
// none.captureWave = 40;
// none.startWaveTimeMultiplier = 3;
// none.localizedName = "none";
// exports.none = none;