const lib = require("前置/全部引用及前置");


const a = extend(Block, "hjgz-dxtq-kw", { //环境改造-地形提取-矿物
    setBars() {
        this.super$setBars();
        this.addBar("提取",
        func(e => new Bar(
        prov(() => e.d1() + e.b1()),
        prov(() => Color.valueOf("#C2FFDD"), 1),
        floatp(() => 1))));
    },
    setStats() {
        this.super$setStats();
        this.stats.add(lib.信息.环境改造矿, new JavaAdapter(StatValue, {
            display(table) {
                table.row();
                table.add(lib.lib.翻译A("item", "内容001"));
                table.row();
                table.table(cons(row => {
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("铜")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("铜"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("铅")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("铅"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("煤")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("煤"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("钛")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("钛"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("钍")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("钍"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("废料")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("废料"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("铍")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("铍"))
                    }))
                        .size(64);
                    row.button(new Packages.arc.scene.style.TextureRegionDrawable(lib.lib.材质 ("钨")), Styles.cleari, run(() => {
                        Vars.ui.content.show(lib.lib.物品 ("钨"))
                    }))
                        .size(64);
                    row.row();
                }))
            }
        }));
    }
});
a.buildType = prov(() => {
    const TXSJ = 600;
    let T = 0.0;
    return extend(Building, {
        init(tile, team, shouldAdd, rotation) {
            if (!this.initialized) this.create(tile.block(), team)
            else if (this.block.hasPower) {
                this.power.init = false;
                new PowerGraph()
                    .add(this);
            };
            this.proximity.clear();
            this.rotation = rotation;
            this.tile = tile;
            this.set(tile.drawx(), tile.drawy());
            if (shouldAdd) this.add();
            this.created();

            this.a0(null);
            this.b0(null);
            return this;
        },
        updateTile() {
            T += Time.delta;
            this.dump()
            let a = Vars.world.tile(this.tileX(), this.tileY())
                .overlay(); //检测覆盖层
            a == Blocks.air ? this.b0(lib.lib.翻译A("block", "hjgz-dxtq-kw-a")) : this.b0(a);
            if (a == Blocks.air) return;
            if (Math.floor(TXSJ - T) < 0) return;
            if (Vars.ui != null && Core.settings.getBool("effects")) {
                Vars.ui.showLabel((Math.floor((TXSJ - T) / 60.0) + "s"), 0.01, this.x, this.y);
            }
            if (Math.floor(TXSJ - T) > 0) return;
            switch (a) {
                case Blocks.oreCopper:
                    this.c1();
                    this.items.add(lib.lib.物品 ("铜"), 1);
                    break;
                case Blocks.oreLead:
                    this.c1();
                    this.items.add(lib.lib.物品 ("铅"), 1);
                    break;
                case Blocks.oreScrap:
                    this.c1();
                    this.items.add(lib.lib.物品 ("废料"), 1);
                    break;
                case Blocks.oreCoal:
                    this.c1();
                    this.items.add(lib.lib.物品 ("煤"), 1);
                    break;
                case Blocks.oreTitanium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钛"), 1);
                    break;
                case Blocks.oreThorium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钍"), 1);
                    break;
                case Blocks.oreBeryllium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("铍"), 1);
                    break;
                case Blocks.oreTungsten:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钨"), 1);
                    break;
                case Blocks.oreCrystalThorium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钍"), 1);
                    break;
                case Blocks.wallOreThorium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钍"), 1);
                    break;
                case Blocks.wallOreBeryllium:
                    this.c1();
                    this.items.add(lib.lib.物品 ("铍"), 1);
                    break;
                case Blocks.wallOreTungsten:
                    this.c1();
                    this.items.add(lib.lib.物品 ("钨"), 1);
                    break;
            }
        },
        a0(a) {
            this.a = a;
        },
        a1() {
            return this.a;
        },
        b0(a) {
            this.b = a;
        },
        b1() {
            if (Math.floor(TXSJ - T) < 0) return lib.lib.翻译A("block", "hjgz-dxtq-kw-b");
            return this.b;
        },
        c1() {
            let b = Vars.world.tile(this.tileX(), this.tileY())
                .floor(); //检测地板
            Vars.world.tile(this.tileX(), this.tileY())
                .setFloorNet(b, Blocks.air);
            return;
        },
        d1() {
            if (Math.floor(TXSJ - T) < 0) return lib.lib.翻译A("block", "hjgz-dxtq-kw-d");
            return lib.lib.翻译A("block", "hjgz-dxtq-kw-c");
        },
        draw() { //绘制
            this.super$draw();
            let a = Vars.world.tile(this.tileX(), this.tileY())
                .overlay(); //检测覆盖层
            a == Blocks.air ? Draw.color(lib.颜色.红色) : Draw.color(lib.颜色.白色);
            Draw.alpha(0.5); //透明度
            //Draw.blend(Blending.additive); //混合
            Draw.z(86); //涂层层数?
            Draw.rect(lib.lib.材质 ("hjgz-kw"), this.x, this.y, 32, 32, Time.time);
        }
    });
});
a.update = true;
a.health = 60; //血量
a.size = 1; //大小
a.hasItems = true;
a.flameColor = Color.valueOf("ffc099");
a.itemCapacity = 10; //物品容量
a.buildVisibility = BuildVisibility.shown;
a.category = Category.crafting;


/*
this.timer.get(时间); //计时器

    this.items.total(); //全部物品？
    this.items.get(物品); //检测物品数量
    this.items.has(物品, 数量); //检测物品数量数量>数量
    this.items.set(物品, 数量); //设置物品？
    this.items.add(物品, 数量); //生成物品
    this.items.remove(物品, 数量); //清除物品


    this.liquids.get(流体); //检测流体数量
    this.liquids.add(流体, 数量); //生成流体
    this.liquids.remove(流体, 数量); //清除流体
    this.liquidsreset(流体, 数量); //重置？
    this.items.current(); //最后接收或装载的流体

    this.dump(); //导出
    this.dump(物品); //导出物品
    this.dumpLiquid(流体); //导出流体
    this.dumpPayload(载荷); //导出载荷

    this.power.status(); //关于电力
    Time.delta;//全局增量
Mathf.chance(0.5);//几率
Mathf.randomBoolean(0.5);//几率

item.copper.name = 铜
item.lead.name = 铅
item.coal.name = 煤炭
item.graphite.name = 石墨
item.titanium.name = 钛
item.thorium.name = 钍
item.silicon.name = 硅
item.plastanium.name = 塑钢
item.phase-fabric.name = 相位织物
item.surge-alloy.name = 巨浪合金
item.spore-pod.name = 孢子荚
item.sand.name = 沙
item.blast-compound.name = 爆炸混合物
item.pyratite.name = 硫化物
item.metaglass.name = 钢化玻璃
item.scrap.name = 废料

item.fissile-matter.name = 裂变物质
item.beryllium.name = 铍
item.tungsten.name = 钨
item.oxide.name = 氧化物
item.carbide.name = 碳化物
item.dormant-cyst.name = 休眠囊肿

liquid.water.name = 水
liquid.slag.name = 矿渣液
liquid.oil.name = 石油
liquid.cryofluid.name = 冷冻液
liquid.neoplasm.name = 囊肿血浆
liquid.arkycite.name = 芳油
liquid.gallium.name = 镓液
liquid.ozone.name = 臭氧
liquid.hydrogen.name = 氢气
liquid.nitrogen.name = 氮气
liquid.cyanogen.name = 氰气
*/