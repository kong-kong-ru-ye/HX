const lib = require("前置/全部引用及前置");
const a = extend(Wall, "hjgz-hd-wj", {});
a.update = true;
a.size = 1;
a.health = 1;
a.requirements = ItemStack.with(
Items.copper, 5,
Items.lead, 6);
a.buildType = prov(() => {
    let timer = 60 * 5;
    return extend(Building, {
        updateTile() {
            if (this.timer.get(timer)) {
                let klk = Vars.world.tile(this.tileX(), this.tileY())
                    .floor(); //检测地板
                if (!(lib.检测.液体地板1.includes(klk) || lib.检测.液体地板2.includes(klk) || lib.检测.液体地板3.includes(klk))) {
                    for (let i = 0; i < 4; i++) {
                        let sj = this.tile.nearby(i)
                            .floor(); //检测地板
                        if (lib.检测.液体地板1.includes(sj)) {
                            this.bb(Blocks.water); //Blocks.water←
                        };
                        if (lib.检测.液体地板2.includes(sj)) {
                            this.bb(Blocks.taintedWater); //Blocks.taintedWater←
                        };
                        if (lib.检测.液体地板3.includes(sj)) {
                            this.bb(sj);
                        };
                    }
                }
            }
        },
        bb(a) {
            let llk = Vars.world.tile(this.tileX(), this.tileY())
                .overlay(); //检测覆盖层
            Vars.world.tile(this.tileX(), this.tileY())
                .setFloorNet(a, llk);
            Vars.world.tile(this.tileX(), this.tileY())
                .setAir();
            return;
        }
    });
});
a.buildVisibility = BuildVisibility.shown;
a.category = Category.effect;





/*
this.timer.get(时间); //计时器

    this.items.total(); //全部物品？
    this.items.get(物品); //检测物品数量
    this.items.has(物品, 数量); //检测物品数量数量>数量
    this.items.set(物品, 数量); //设置物品？
    this.items.add(物品, 数量); //生成物品
    this.items.remove(物品, 数量); //清除物品


    this.liquids.get(流体); //检测流体数量
    this.liquids.add(流体, 数量); //生成流体
    this.liquids.remove(流体, 数量); //清除流体
    this.liquidsreset(流体, 数量); //重置？
    this.items.current(); //最后接收或装载的流体

    this.dump(); //导出
    this.dump(物品); //导出物品
    this.dumpLiquid(流体); //导出流体
    this.dumpPayload(载荷); //导出载荷

    this.power.status(); //关于电力
    Time.delta;//全局增量
Mathf.chance(0.5);//几率
Mathf.randomBoolean(0.5);//几率

item.copper.name = 铜
item.lead.name = 铅
item.coal.name = 煤炭
item.graphite.name = 石墨
item.titanium.name = 钛
item.thorium.name = 钍
item.silicon.name = 硅
item.plastanium.name = 塑钢
item.phase-fabric.name = 相位织物
item.surge-alloy.name = 巨浪合金
item.spore-pod.name = 孢子荚
item.sand.name = 沙
item.blast-compound.name = 爆炸混合物
item.pyratite.name = 硫化物
item.metaglass.name = 钢化玻璃
item.scrap.name = 废料

item.fissile-matter.name = 裂变物质
item.beryllium.name = 铍
item.tungsten.name = 钨
item.oxide.name = 氧化物
item.carbide.name = 碳化物
item.dormant-cyst.name = 休眠囊肿

liquid.water.name = 水
liquid.slag.name = 矿渣液
liquid.oil.name = 石油
liquid.cryofluid.name = 冷冻液
liquid.neoplasm.name = 囊肿血浆
liquid.arkycite.name = 芳油
liquid.gallium.name = 镓液
liquid.ozone.name = 臭氧
liquid.hydrogen.name = 氢气
liquid.nitrogen.name = 氮气
liquid.cyanogen.name = 氰气
*/