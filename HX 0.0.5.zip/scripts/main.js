
//try {
//require("原版绘制")
require("通用方块/隐藏的科技方块")

require("环境改造/物质")
//require("环境改造/阿尔山")
require("环境改造/河道")
require("环境改造/提取矿物")
require("环境改造/填充矿物")
require("环境改造/环境改造科技树")
require("newPlanet")


// } catch (e) {
//  print("发生了错误: ⇨⇨⇨⇨⇨" + e);
// }