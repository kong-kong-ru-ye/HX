

exports.类型A = require("前置/信息类型");
exports.信息 = require("前置/信息");
exports.单位A = require("前置/信息的单位");
exports.标签 = require("前置/标签");
exports.颜色 = require("前置/颜色");
exports.特效 = require("前置/特效");
exports.检测 = require("前置/检测");
exports.lib = require("前置/lib");
exports.java = require("前置/java");